export interface IEvent {
  name: string;
  description: string;
  startDate: Date;
}
